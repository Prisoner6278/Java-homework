package graphs.queries;

import java.util.ArrayList;
import java.util.Collection;

import graphs.IndexedGraph;

public class DepthFirstPath 
{
	public DepthFirstPath(IndexedGraph g, int source)
	{
	}

	/**
	 * Return a path from the vertex provided to the original source
	 * @param to any vertex in the graph
	 * @return a collection of vertices that is the path, or 
	 *   an empty collection if the vertex is not connected
	 */
	public Collection<Integer> getPath(int to)
	{
		return new ArrayList<Integer>();
	}
	
	/**
	 * Check connectivity to the source vertex
	 * @param vertex - the vertex to check connectivity
	 * @return true if connected
	 */
	public boolean isConnected(int vertex)
	{
		return false;
	}

	/**
	 * Determine the number of vertices in the subgraph
	 * @return the count
	 */
	public int getCount()
	{
		return 0;
	}
}