package graphs.queries;

import graphs.IndexedGraph;

public class DepthFirstConnectivity
{
	/**
	 * @param g - the graph to search
	 */
	public DepthFirstConnectivity(IndexedGraph g)
	{
	}

	/**
	 * Determine if two vertices are connected 
	 * @param from - the first vertex id
	 * @param to - the second vertex id
	 * @return true if connected
	 */
	public boolean connected(int from, int to)
	{
		return false;
	}
	
	/**
	 * Determines the number of subgraphs
	 * @return the count of subgraphs in the graph
	 */
	public int getNumberOfDisconnectedSubgraphs()
	{
		return 0;
	}
}