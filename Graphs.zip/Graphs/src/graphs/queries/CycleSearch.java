package graphs.queries;

import graphs.IndexedGraph;

public class CycleSearch
{
	/**
	 * @param g the graph to search
	 */
	public CycleSearch(IndexedGraph g)
	{
	}

	/**
	 * @return true if the graph contains a cycle
	 */
	public boolean containsCycle()
	{
		return false;
	}
}