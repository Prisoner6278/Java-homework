package graphs.test.queries;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.gradescope.jh61b.grader.GradedTest;

import graphs.ArrayGraph;
import graphs.IndexedGraph;
import graphs.queries.DepthFirstConnectivity;
import graphs.test.GraphTestHelper;

public class SubgraphTest
{
    @Test		
    @GradedTest(name="Test DepthFirstConnectivity", max_score=10)
    public void testPath()
    {
    	IndexedGraph g = new ArrayGraph(GraphTestHelper.LINKED_COUNT);
    	GraphTestHelper.setupGraph(g, false);
    	DepthFirstConnectivity uut = new DepthFirstConnectivity(g);
    	assertEquals("Count does not match ", 2, uut.getNumberOfDisconnectedSubgraphs());
    	assertTrue("Mom is not connected to Daughter", uut.connected(GraphTestHelper.MOM, GraphTestHelper.DAUGHTER));
    	assertFalse("Mayor is connected to Daughter and should not be", uut.connected(GraphTestHelper.MAYOR, GraphTestHelper.DAUGHTER));
    	assertTrue("Mayor is not connected to Athlete", uut.connected(GraphTestHelper.MAYOR, GraphTestHelper.ATHLETE));
    }	
}