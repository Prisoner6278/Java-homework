package graphs.test;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;

import com.gradescope.jh61b.grader.GradedTest;

import graphs.ArrayGraph;
import graphs.IndexedGraph;

public class GraphTest
{
	private static final int SIZE = 100;
	
    @Test		
    @GradedTest(name="Test Graph(), getNumberOfVerticies()", max_score=5)
    public void testInit()
    {
    	IndexedGraph uut = new ArrayGraph(SIZE);
    	assertEquals("The size of the created Graph does not match", SIZE,  uut.getNumberOfVerticies());
    	assertEquals("The new Graph has edges before adding", 0,  uut.getNumberOfEdges());
    }
    
    @Test		
    @GradedTest(name="Test add(), getAdjacent(), getNumberOfEdges()", max_score=5)
    public void testAdd()
    {
    	int bonusTest = SIZE/4;
    	testInit();
    	IndexedGraph uut = new ArrayGraph(SIZE);
    	Collection<Integer> expected = new ArrayList<Integer>();
    	assertArrayEquals("Your graph reported edges at vertex 0 before any were added", expected.toArray(), uut.getAdjacent(0).toArray());
    	for (int i = SIZE - 1; i > SIZE / 2; i--)
    	{
    		expected.add(i);
    		assertTrue("Your graph did not add the expected value " + i, uut.addEdge(0, i));
    		assertTrue("Your graph did not add the expected value " + i, uut.addEdge(bonusTest, i));
    	}
    	
    	assertArrayEquals("Your graph did not save the expected edges to vertex 0", expected.toArray(), uut.getAdjacent(0).toArray());
    	assertArrayEquals("Your graph did not save the expected edges to vertex " + bonusTest, expected.toArray(), uut.getAdjacent(bonusTest).toArray());
    	assertEquals("The Graph reported the wrong size", expected.size() * 2,  uut.getNumberOfEdges());
    }

    @Test		
    @GradedTest(name="Test remove()", max_score=5)
    public void testRemove()
    {
    	testAdd();
    	IndexedGraph uut = new ArrayGraph(SIZE);
    	Collection<Integer> expected = new ArrayList<Integer>();
    	for (int i = SIZE - 1; i > SIZE / 2; i--)
    	{
    		expected.add(i);
    		uut.addEdge(0, i);
    	}

    	for (int i = SIZE - 1; i > SIZE / 2; i--)
    	{
    		expected.remove(i);
    		uut.removeEdge(0, i);
        	assertEquals("The number of edges did nto match expected", expected.size(), uut.getNumberOfEdges());
        	assertArrayEquals("The vertex 0 should did not match expected", expected.toArray(), uut.getAdjacent(0).toArray());
    	}
    	
    }

    @Test		
    @GradedTest(name="Test Exceptional Cases", max_score=5)
    public void testExceptions()
    {
    	testRemove();
    	IndexedGraph uut = new ArrayGraph(SIZE);
    	assertFalse("Your code reported you added at " + SIZE + " which is greater than the size", uut.addEdge(0, SIZE));
    	assertFalse("Your code reported you added at -1 which is nonsensical", uut.addEdge(0, -1));
    	assertFalse("Your code reported it removed an edge that was not in the edges", uut.removeEdge(0, 1));
   }
}