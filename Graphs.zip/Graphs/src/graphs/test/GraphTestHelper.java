package graphs.test;

import graphs.IndexedGraph;

public class GraphTestHelper
{
	public static final int UNLINKED_COUNT = 9;
	public static final int LINKED_COUNT   = 15;
	public static final int MOM            = 0;
	public static final int DAD            = 1;
	public static final int SON            = 2;
	public static final int DAUGHTER       = 3;
	public static final int CUSTODIAN      = 5;
	public static final int NEIGHBOR       = 6;
	public static final int COWORKER       = 8;
	public static final int MAYOR          = 9;
	public static final int ATHLETE        = 12;
	public static final Object[] CUSTODIAN_DEPTH_PATH  = {5, 4, 2, 1, 0, 8};
	public static final Object[] CUSTODIAN_BREADTH_PATH = {5, 4, 2, 0, 8};
	public static final Object[] MAYOR_DEPTH_PATH      = {9, 11, 13, 14, 7, 1, 0, 8};
	public static final Object[] MAYOR_BREADTH_PATH     = {9, 11, 13, 14, 7, 1, 0, 8};
	private static final int[][] TEST_EDGES = {{0, 1}, {0, 2}, {0, 3}, {1, 2}, {1, 3}, {2, 3}, {2, 4},  {4, 5},  
										 {1, 6}, {1, 7}, {0, 8}, {3, 6}, 
										 {9, 10}, {9, 11}, {11, 13}, {12, 13}, {13, 14}};
	
	public static void setupGraph(IndexedGraph g, boolean linked)
	{
		setupGraph(g, TEST_EDGES, linked);
	}

	public static void setupGraph(IndexedGraph g, int[][] edges, boolean linked)
	{
		for (int[] vertices : edges)
		{
			g.addEdge(vertices[0], vertices[1]);
		}
		
		if (linked)
		{
			link(g);
		}
	}	
	
	public static void link(IndexedGraph g)
	{
		g.addEdge(7, 14);
	}
}