package graphs;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;

public class ArrayGraph implements IndexedGraph
{
	private int numberOfEdges;
	private Collection<Integer>[] edges; // [[0,1], [1,2], [2,3]] //Use it for getNumberOfEdges(), addEdge, removeEdge
	
	@SuppressWarnings("unchecked")
	public ArrayGraph(int veritcies)
	{
		this.numberOfEdges = numberOfEdges;
		edges = new LinkedList[numberOfEdges];
		for (int i = 0; i < numberOfEdges; i++) {
			edges[i] = new LinkedList<>();
		}
		
//		this.numberOfEdges = numberOfEdges;
//		edges = (Collection<Integer>[]) new Collection[numberOfEdges];
//		for (int i = 0; i < numberOfEdges; i++) {
//			edges[i] = new Collection <Integer>();
//		}
		
	}

	@Override
	public int getNumberOfVerticies()
	{
		
		return 0;
	}

	@Override
	public int getNumberOfEdges()
	{
		return edges.length;
	}

	@Override
	public boolean addEdge(Integer from, Integer to)
	{
		
		return false;
	}

	@Override
	public Collection<Integer> getAdjacent(Integer to)
	{
		return new ArrayList<Integer>();
	}

	@Override
	public boolean removeEdge(Integer from, Integer to)
	{
		return false;
	}
}