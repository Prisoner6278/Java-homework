package graphs;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public class SymbolGraph<E> implements Graph<E>
{
	private Map<E, List<E>> edges;
	private int numberOfEdges;
	
	public SymbolGraph()
	{
	}

	@Override
	public int getNumberOfVerticies()
	{
		return 0;
	}

	@Override
	public int getNumberOfEdges()
	{
		return 0;
	}

	public boolean addVertex(E value)
	{
		return false;
	}
	
	@Override
	public boolean addEdge(E from, E to)
	{
		return false;
	}

	@Override
	public Collection<E> getAdjacent(E to)
	{
		return new ArrayList<E>();
	}

	@Override
	public boolean removeEdge(E from, E to)
	{
		return false;
	}	
}