package graphs;

public interface IndexedGraph extends Graph<Integer>
{

}